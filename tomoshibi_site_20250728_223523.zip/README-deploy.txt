Tomoshibi v5 Fusion PRO — Static Site
=====================================

構成:
- index.html   … アプリ本体（JS内蔵・外部送信なし）
- about.html   … CUS/RIS/EIS/SSS と FAS の説明
- privacy.html … プライバシ方針（ローカル処理）
- changelog.html … 更新履歴
- 404.html     … GitHub Pages 用のフォールバック

GitHub Pages 公開手順（最短）:
1. GitHub で新規リポジトリを作成（例: tomoshibi-ui）
2. 上記ファイルをそのままリポジトリのルートにアップロード（main ブランチ）
3. Settings → Pages → Source: 「Deploy from a branch」 / Branch: main / フォルダ: /(root) を選択 → Save
4. 数分待つと公開 URL が発行されます（例）https://<ユーザー名>.github.io/tomoshibi-ui/

iPhone の注意:
- Files の「プレビュー」では JS が動きません。公開 URL で開いてください。

バージョン: Tomoshibi v5 Fusion PRO (MaxSummary) — 2025-07-28 22:35:23
